!function ($) {
  $(function(){


	$('.zoom').zoomy(



    );


	 
	

})
}(window.jQuery)

